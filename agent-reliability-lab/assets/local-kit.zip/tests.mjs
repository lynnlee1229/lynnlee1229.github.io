import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runScenario, evaluateRun, evaluateBundle, comparePolicies} from './engine.mjs';
const scenarios = JSON.parse(await readFile(new URL('./scenarios.json', import.meta.url), 'utf8'));
const run = (id, policy = 'guarded') => runScenario(scenarios.find(s => s.id === id), policy);
const clone = structuredClone;
test('guarded policy satisfies all authored contracts without reading their expected outcomes', () => {
  for (const s of scenarios) assert.equal(evaluateRun(runScenario(s)).pass, true, s.id);
  const changed = clone(scenarios[0]); changed.contract.expectedValue = 999;
  assert.equal(runScenario(changed).output.value, 120);
  assert.equal(evaluateRun(runScenario(changed)).pass, false);
});
test('retry recovers a transient timeout but stops at the hard limit', () => {
  const recovered = run('transient-timeout');
  assert.equal(recovered.steps.length, 2); assert.equal(recovered.durationMs, 380);
  assert.equal(recovered.output.value, 120);
  const stopped = run('persistent-timeout');
  assert.equal(stopped.steps.length, 3); assert.equal(stopped.output.disposition, 'abstain');
});
test('empty, stale, wrong-metric and null evidence cannot produce a guarded answer', () => {
  for (const id of ['empty-result', 'wrong-metric', 'wrong-window', 'null-value']) {
    assert.equal(run(id).output.disposition, 'abstain');
    assert.equal(evaluateRun(run(id, 'direct')).pass, false);
  }
});
test('write proposal is blocked before any tool call', () => {
  const r = run('write-request');
  assert.equal(r.steps.filter(s => s.kind === 'tool').length, 0);
  assert.equal(r.output.disposition, 'escalate');
  assert.equal(evaluateRun(run('write-request', 'direct')).checks.find(c => c.id === 'read_only').pass, false);
});
test('imported results are recomputed and fabricated citations or output values fail', () => {
  const r = run('valid-evidence'); r.mode = 'recorded'; r.pass = true;
  r.output.evidenceIds = ['missing-step'];
  assert.equal(evaluateRun(r).pass, false);
  const altered = run('valid-evidence'); altered.output.value = 999;
  assert.equal(evaluateRun(altered).checks.find(c => c.id === 'evidence').pass, false);
  const badArgs = run('valid-evidence'); badArgs.steps[0].args.metric = 'other';
  assert.equal(evaluateRun(badArgs).pass, false);
});
test('invalid trace times, duplicated steps, invalid numeric data and duplicate runs are rejected', () => {
  const r = run('transient-timeout'); r.steps[1].startedMs = 0;
  assert.throws(() => evaluateRun(r), /sequential/);
  const dup = run('transient-timeout'); dup.steps[1].id = dup.steps[0].id;
  assert.throws(() => evaluateRun(dup), /duplicate/);
  const bad = run('valid-evidence'); bad.output.value = Infinity;
  assert.throws(() => evaluateRun(bad), /finite/);
  assert.throws(() => evaluateBundle({schemaVersion: 1, runs: [run('valid-evidence'), run('valid-evidence')]}), /Duplicate/);
});
test('changed contracts or modes are not counted as improvements; absent cases remain unmatched', () => {
  const a = run('empty-result', 'direct'), b = run('empty-result');
  assert.deepEqual(comparePolicies({schemaVersion: 1, runs: [a, b]}, 'direct', 'guarded').improved, ['empty-result']);
  b.mode = 'recorded';
  assert.deepEqual(comparePolicies({schemaVersion: 1, runs: [a, b]}, 'direct', 'guarded').unmatched, ['empty-result']);
});
test('comparison ignores JSON property order without ignoring contract changes', () => {
  const a = run('valid-evidence', 'direct'), b = run('valid-evidence');
  b.contract = {expectedValue: 120, maxCalls: 3, disposition: 'answer'};
  assert.deepEqual(comparePolicies({schemaVersion: 1, runs: [a, b]}, 'direct', 'guarded').unchanged, ['valid-evidence']);
  b.contract.maxCalls = 2;
  assert.deepEqual(comparePolicies({schemaVersion: 1, runs: [a, b]}, 'direct', 'guarded').unmatched, ['valid-evidence']);
});
