# Agent Reliability Lab · local kit / 本地运行包

Requires Node.js 18+. No package installation, network, model key or live tool service.
需要 Node.js 18+，无需安装依赖、联网、模型密钥或真实工具服务。

```sh
node cli.mjs --policy guarded --out guarded.json
node cli.mjs --policy both --out comparison.json
node cli.mjs --input your-runs.json --out checked.json
node --test tests.mjs
```

Exit 0: every case passes. Exit 1: at least one case fails. Exit 2: invalid input or runner error.
The direct policy deliberately fails several cases; `--policy both` normally exits 1.
退出码 0：全部通过；1：存在失败；2：输入或运行错误。直接策略刻意保留缺陷，both 模式正常会返回 1。

The engine runs deterministic policies over synthetic tool replies. Expected contracts are used
only by the evaluator, not by a policy. Fixture duration is a declared logical clock, not model latency.
Scores cover scalar metric queries, read-only boundaries, call budgets and evidence references.
They do not evaluate natural-language reasoning, general Agent quality or actual authorization.

核心用确定性策略处理合成工具回复。预期契约仅用于评分，不参与策略决策。
样例耗时为声明的逻辑时钟，不代表模型延迟。评分覆盖标量指标查询、只读边界、调用预算与证据引用，
不评价自然语言推理、通用 Agent 质量或实际权限执行。

To import observations, adapt your application exporter to the native format shown in
`example-runs.json` and `format.json`. Use `mode: "recorded"`. Keep steps sequential, use
milliseconds relative to run start, and retain unsuccessful attempts. Concurrent spans need
an explicit sequential adapter; this is not a generic OTLP importer. The `source` field is an
assertion, not an authenticity check. Review your expected contract independently.

导入真实记录时，按 example-runs.json 和 format.json 编写适配，使用 recorded 模式；
保留失败尝试，步骤顺序执行，时间取相对起点的毫秒数。并发 span 需要明确适配，不能当成通用 OTLP 导入。
source 字段只是来源声明，预期契约也需要独立复核。

Online guide: https://lynnlee1229.github.io/agent-reliability-lab/en/guide/
中文指南：https://lynnlee1229.github.io/agent-reliability-lab/zh/guide/

Companion source / 配套开源项目：https://github.com/lynnlee1229/agent-reliability-lab

To develop your checks, edit engine.mjs and add cases to scenarios.json. Keep successful cases
in tests.mjs while adding a failing example, then rerun the full test suite and your own records.
The companion is MIT-licensed; it contains only the portable evaluator, runner, fixtures and tests.
The homepage website and GeoData project are not included in this license.

开发自己的检查时，修改 engine.mjs，在 scenarios.json 添加案例，并保留 tests.mjs 中原有的成功案例。
先加入失败反例，再运行完整测试集与自己的真实记录。独立配套项目采用 MIT 许可，范围为可移植评分核心、
运行器、样例与测试；不包含主页网站或 GeoData 项目。
