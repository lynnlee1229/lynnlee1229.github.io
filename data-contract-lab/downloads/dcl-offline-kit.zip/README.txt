DCL/1 original offline exercises / DCL/1 原创离线练习
Node 18+. No dependencies, API key or network.
Run: node run.mjs all
Run one: node run.mjs U04
Save: node run.mjs U05 --out repaired-check.json
Edit nested-input-bundle.json, then replay your edits:
node run.mjs replay --bundle nested-input-bundle.json --out contract-report.json --csv errors.csv
Repair new.schema.properties.records.items.properties["quantity/unit~"].maximum from 9 to 8. Rerun the replay command; inspect the report.
Keep the U01-U06 probe inputs unchanged; their assertions describe the original exercise. The replay command accepts your edited bundle.
The case-specific oracle in exercises/oracle.mjs imports no engine code.
These are original exercises, not university assignment solutions.
DCL/1 is restricted, not JSON Schema/Pact/ODCS. No model is called or evaluated.
