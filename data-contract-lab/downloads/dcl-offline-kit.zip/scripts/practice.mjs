#!/usr/bin/env node
import fs from 'node:fs';
import {UNIT_IDS,runUnit} from '../src/practice.mjs';
import {parseJSON,run,csv} from '../src/core.mjs';
import {nestedExercise} from '../src/nested-exercise.mjs';
const selected=process.argv[2]||'all';
const option=key=>{const i=process.argv.indexOf(key);if(i<0)return undefined;if(!process.argv[i+1])throw Error(key+' requires a path');return process.argv[i+1];};
let result;
if(selected==='replay'){
 const file=option('--bundle'),bundle=file?parseJSON(fs.readFileSync(file,'utf8')):nestedExercise;
 if(!bundle||Object.keys(bundle).sort().join(',')!=='consumers,events,new,old'||typeof bundle.events!=='string')throw Error('Bundle needs exactly old, new, consumers, events.');
 result=run(bundle.old,bundle.new,bundle.consumers,bundle.events);
 const csvFile=option('--csv');if(csvFile)fs.writeFileSync(csvFile,csv(result));
}else result={format:'dcl-practice/1',executedAt:new Date().toISOString(),kind:'Actual offline engine execution on original synthetic exercises',units:(selected==='all'?UNIT_IDS:[selected]).map(runUnit)};
const i=process.argv.indexOf('--out');
if(i>=0){if(!process.argv[i+1])throw Error('--out requires a path');fs.writeFileSync(process.argv[i+1],JSON.stringify(result,null,2)+'\n');}
console.log(JSON.stringify(result,null,2));
